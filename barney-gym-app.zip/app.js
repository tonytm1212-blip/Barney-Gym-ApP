// Barney Gym App - Navigation & Data

// Placeholder workout data structure
const workouts = {
  1: {
    name: 'Phase I',
    color: 'red-400',
    days: {
      1: [
        { name: 'Barbell Squats', sets: '4-6 x 1-4' },
        { name: 'Bench Press', sets: '4-6 x 1-4' },
        { name: 'Pull-Ups', sets: '3 x 8-10' },
      ],
      2: [
        { name: 'Deadlift', sets: '4-6 x 1-4' },
        { name: 'Overhead Press', sets: '3 x 8-10' },
        { name: 'Rows', sets: '3 x 8-10' },
      ],
    },
  },
  2: {
    name: 'Phase II',
    color: 'blue-400',
    days: {
      1: [
        { name: 'Front Squats', sets: '3 x 8-12' },
        { name: 'Incline DB Press', sets: '3 x 8-12' },
        { name: 'Lat Pulldown', sets: '3 x 10-12' },
      ],
      2: [
        { name: 'Romanian Deadlift', sets: '3 x 8-12' },
        { name: 'Arnold Press', sets: '3 x 10-12' },
        { name: 'Seated Row', sets: '3 x 10-12' },
      ],
    },
  },
  3: {
    name: 'Phase III',
    color: 'green-400',
    days: {
      1: [
        { name: 'Goblet Squat', sets: '4 x 15-20' },
        { name: 'Push-Ups', sets: '4 x 15-20' },
        { name: 'Band Pull-Apart', sets: '4 x 20' },
      ],
      2: [
        { name: 'Kettlebell Swing', sets: '4 x 15-20' },
        { name: 'Dips', sets: '4 x 15-20' },
        { name: 'Face Pull', sets: '4 x 20' },
      ],
    },
  },
};

// Screen elements
const startScreen = document.getElementById('start-screen');
const phaseScreen = document.getElementById('phase-screen');
const dayScreen = document.getElementById('day-screen');
const exerciseScreen = document.getElementById('exercise-screen');
const exerciseList = document.getElementById('exercise-list');

let selectedPhase = null;
let selectedDay = null;

function showScreen(screen) {
  [startScreen, phaseScreen, dayScreen, exerciseScreen].forEach(s => s.classList.add('hidden'));
  screen.classList.remove('hidden');
}

// Start button
const startBtn = document.getElementById('start-btn');
if (startBtn) {
  startBtn.onclick = () => {
    showScreen(phaseScreen);
  };
}

// Phase selection
Array.from(document.getElementsByClassName('phase-select')).forEach(btn => {
  btn.onclick = (e) => {
    selectedPhase = btn.getAttribute('data-phase');
    showScreen(dayScreen);
  };
});

// Day selection
Array.from(document.getElementsByClassName('day-select')).forEach(btn => {
  btn.onclick = (e) => {
    selectedDay = btn.getAttribute('data-day');
    renderExercises();
    showScreen(exerciseScreen);
  };
});

// Back buttons
Array.from(document.getElementsByClassName('back-btn')).forEach(btn => {
  btn.onclick = () => {
    if (exerciseScreen && !exerciseScreen.classList.contains('hidden')) {
      showScreen(dayScreen);
    } else if (dayScreen && !dayScreen.classList.contains('hidden')) {
      showScreen(phaseScreen);
    }
  };
});

// Home buttons
Array.from(document.getElementsByClassName('home-btn')).forEach(btn => {
  btn.onclick = () => {
    showScreen(startScreen);
  };
});

// Render exercises for selected phase/day
function renderExercises() {
  exerciseList.innerHTML = '';
  if (!selectedPhase || !selectedDay) return;
  const phase = workouts[selectedPhase];
  const day = phase.days[selectedDay];
  day.forEach(ex => {
    const card = document.createElement('div');
    card.className = `exercise-card bg-${phase.color} text-white p-4 shadow-lg flex flex-col items-center`;
    card.innerHTML = `<div class="text-xl mb-2">${ex.name}</div><div class="text-lg font-bold">${ex.sets}</div>`;
    exerciseList.appendChild(card);
  });
}

// On load, show start screen
showScreen(startScreen); 